
/*

  KLayout Layout Viewer
  Copyright (C) 2006-2026 Matthias Koefferlein

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/


#include "dbCellInst.h"
#include "dbLayout.h"

namespace db
{

CellInst::box_type 
CellInst::bbox (const db::Layout &g) const
{
  return g.cell (m_cell_index).bbox ();
}

CellInst::box_type
CellInst::bbox_with_empty (const db::Layout &g) const
{
  return g.cell (m_cell_index).bbox_with_empty ();
}

CellInst::box_type
CellInst::bbox (const db::Layout &g, unsigned int l) const
{
  return g.cell (m_cell_index).bbox (l);
}

std::string 
CellInst::to_string () const
{
  return "[" + tl::to_string (m_cell_index) + "]";
}

}

